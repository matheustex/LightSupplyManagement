import { DB } from '../../shared/db';
const db: DB = new DB();

module.exports.get = async (event, context, callback) => {
  const res = await db.get(process.env.ORDERS_TABLE, event.pathParameters.id);

  res.then(result => {
    const response = {
      statusCode: 200,
      body: JSON.stringify(result.Item),
    };
    callback(null, response);
  })
    .catch(error => {
      callback(new Error('Could not get user.'));
      return;
    });
};

module.exports.createUser = async (event, context, callback) => {
  const requestBody = JSON.parse(event.body);

  const { fullName, email, age } = requestBody;

  if (typeof fullName !== 'string' || typeof email !== 'string' || typeof age !== 'number') {
    callback(new Error('Could create user because of validation errors.'));
    return;
  }

  const res = await db.create(process.env.ORDERS_TABLE, requestBody);

  res.then(res => {
    callback(null, {
      statusCode: 200,
      body: JSON.stringify({
        message: `Sucessfully submitted user with email ${email}`,
        userId: res.id
      })
    });
  })
    .catch(err => {
      callback(null, {
        statusCode: 500,
        body: JSON.stringify({
          message: `Unable to submit user with email ${email}`
        })
      })
    });
};