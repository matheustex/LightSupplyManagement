import { APIGatewayEvent } from "aws-lambda";

export const get = (event: APIGatewayEvent, context, cb) => {
  const response = {
    statusCode: 200,
    body: JSON.stringify({
      message: 'Go Serverless Webpack (Typescript) v1.0! Your function executed successfully!',
      input: event,
    }),
  };

  cb(null, response);
}

// module.exports.get = async (event, context, callback) => {
//   console.log("starting event");

//   const db: DB = new DB();

//   console.log("starting event");

//   const res = await db.get(process.env.PRODUCTS_TABLE, event.pathParameters.id);

//   res.then(result => {
//     const response = {
//       statusCode: 200,
//       body: JSON.stringify(result.Item),
//     };
//     callback(null, response);
//   })
//     .catch(error => {
//       console.log("error");
//       callback(new Error('Could not get user.'));
//       return;
//     });
// };


// module.exports.createUser = async (event, context, callback) => {
//   console.log("starting event");

//   const requestBody = JSON.parse(event.body);

//   const { fullName, email, age } = requestBody;

//   if (typeof fullName !== 'string' || typeof email !== 'string' || typeof age !== 'number') {
//     callback(new Error('Could create user because of validation errors.'));
//     return;
//   }

//   const res = await db.create(process.env.PRODUCTS_TABLE, requestBody);

//   res.then(res => {
//     callback(null, {
//       statusCode: 200,
//       body: JSON.stringify({
//         message: `Sucessfully submitted user with email ${email}`,
//         userId: res.id
//       })
//     });
//   })
//     .catch(err => {
//       console.log("err");
//       callback(null, {
//         statusCode: 500,
//         body: JSON.stringify({
//           message: `Unable to submit user with email ${email}`
//         })
//       })
//     });
// };