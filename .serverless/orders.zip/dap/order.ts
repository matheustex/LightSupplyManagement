import { Item } from './item';

export class Order {
  ID: string;
  Related: Date;
  Created: Date;
  Approved: Date;
  Status: string;
  Items: Item[];
}