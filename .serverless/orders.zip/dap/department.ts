export class Department {
  ID: string;
  Name: string;
  Type: string;
}