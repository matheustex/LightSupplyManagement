export class Product {
  ID: string;
  Name: string;
  Value: number;
}