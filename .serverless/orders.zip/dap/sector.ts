export class Sector {
  ID: string;
  Name: string;
  DepartmentID: string;
}