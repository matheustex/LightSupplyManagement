export class Item {
  ID: string;
  OrderID: string;
  SectorID: string;
  DepartmentID: string;
  ProductID: string;
  Quantity: number;
  Total: number;
  Created: string;
}