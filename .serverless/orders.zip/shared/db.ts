const uuid = require('uuid');
const AWS = require('aws-sdk');

AWS.config.setPromisesDependency(require('bluebird'));

const dynamoDb = new AWS.DynamoDB.DocumentClient();

export class DB {
  create(table: string, req: any): Promise<any> {
    let item = this.buildModel(req.fullname, req.email, req.age);

    const userInfo = {
      TableName: table,
      Item: item,
    };

    return dynamoDb.put(userInfo).promise();
  }

  get(table: string, id: string): Promise<any> {
    const params = {
      TableName: table,
      Key: {
        id: id
      },
    };

    return dynamoDb.get(params).promise();
  }

  list() {
    return "Teste";
  }

  update() {
    return "Teste";
  }

  delete() {
    return "teste";
  }

  private buildModel(fullname: any, email: any, age: any) {
    const timestamp = new Date().getTime();
    return {
      id: uuid.v1(),
      fullname: fullname,
      email: email,
      age: age,
      submittedAt: timestamp,
      updatedAt: timestamp,
    };
  };
}